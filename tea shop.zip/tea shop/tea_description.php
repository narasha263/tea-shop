<?php include "header.php" ?>  
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tea Descriptions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <header>
        <div class="container">
            <h1>Tea Descriptions</h1>
        </div>
    </header>

    <section class="featured-teas">
        <div class="container">
            <div class="tea-list">
                <!-- Individual Tea Descriptions -->
                <div class="tea-description">
                    <h3>Green Tea</h3>
                    <p>Green tea is made from Camellia sinensis leaves and buds that have not undergone the same withering and oxidation process used to make oolong teas and black teas. It originated in China but has become associated with many cultures throughout Asia. Green tea has a range of health benefits due to its high antioxidant content, including improved brain function, fat loss, and a lower risk of cancer. It also contains caffeine, although in smaller amounts than black tea or coffee.</p>
                </div>
                <div class="tea-description">
                    <h3>Black Tea</h3>
                    <p>Black tea is a type of tea that is more oxidized than oolong, green, and white teas. It is made from the leaves of Camellia sinensis plant, and the oxidation process gives it a stronger flavor compared to other tea varieties. Black tea is widely consumed around the world and is known for its bold and robust taste. It contains caffeine and various antioxidants, offering potential health benefits such as improved heart health and reduced risk of stroke.</p>
                </div>
                <div class="tea-description">
                    <h3>White Tea</h3>
                    <p>White tea is made from the young leaves and buds of the Camellia sinensis plant. It is minimally processed, with the leaves simply withered and dried under controlled conditions. White tea has a delicate flavor profile and is known for its light, floral taste. It contains antioxidants and may offer various health benefits, including improved skin health and enhanced immune function.</p>
                </div>
                <div class="tea-description">
                    <h3>Yellow Tea</h3>
                    <p>Yellow tea is a rare and prized variety of tea that originates from China. It is made from the buds and young leaves of the Camellia sinensis plant and undergoes a unique processing method known as "yellowing." This process involves allowing the tea leaves to yellow slightly before drying, resulting in a mild and mellow flavor profile. Yellow tea is low in caffeine and is believed to offer various health benefits, including relaxation and stress relief.</p>
                </div>
                <div class="tea-description">
                    <h3>Herbal Tea</h3>
                    <p>Herbal tea, also known as tisane, refers to infusions made from herbs, spices, flowers, or other plant materials. Unlike true teas, which are made from the Camellia sinensis plant, herbal teas are caffeine-free and often prized for their medicinal properties and unique flavors. Herbal teas come in a variety of flavors and blends, each offering different health benefits depending on the ingredients used.</p>
                </div>
                <div class="tea-description">
                    <h3>Chamomile Tea</h3>
                    <p>Chamomile tea is an herbal infusion made from the dried flowers of the chamomile plant. It has been used for centuries as a natural remedy for various ailments, including insomnia, anxiety, and digestive issues. Chamomile tea has a mild, floral flavor and is caffeine-free, making it an ideal choice for relaxation and promoting better sleep. It also contains antioxidants and anti-inflammatory compounds, offering potential health benefits.</p>
                </div>
                <div class="tea-description">
                    <h3>Oolong Tea</h3>
                    <p>Oolong tea is a traditional Chinese tea that falls between green tea and black tea in terms of oxidation levels. It is made from the leaves of the Camellia sinensis plant and is prized for its complex flavors and aromas. Oolong tea undergoes a partial oxidation process, which results in a wide range of flavors, from floral and fruity to woody and roasted. It contains caffeine and antioxidants, offering potential health benefits such as improved digestion and weight management.</p>
                </div>
                <div class="tea-description">
                    <h3>Pu-erh Tea</h3>
                    <p>Pu-erh tea is a type of fermented tea that originates from the Yunnan province of China. It is made from the leaves of the Camellia sinensis plant and undergoes a unique fermentation process that results in its distinct flavor profile. Pu-erh tea is often aged, with older varieties prized for their rich, earthy taste and potential health benefits such as improved digestion and cholesterol levels.</p>
                </div>
                <div class="tea-description">
                    <h3>Matcha Tea</h3>
                    <p>Matcha tea is a finely ground powder made from shade-grown green tea leaves. It is traditionally used in Japanese tea ceremonies and has gained popularity worldwide for its vibrant green color and unique flavor. Matcha tea is rich in antioxidants, vitamins, and minerals, making it a nutritious beverage choice. It also contains caffeine and L-theanine, which together provide a calm yet alert feeling.</p>
                </div>
                                                                                                                
                <!-- Add descriptions of other teas -->
            </div>
        </div>
    </section>

   
    <!-- Link to your JavaScript file (if needed) -->
    <script src="scripts.js"></script>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html>
<?php include_once 'footer.php'; ?>