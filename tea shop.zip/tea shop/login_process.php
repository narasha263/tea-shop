<?php


// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $email = $_POST["loginEmail"];
    $password = $_POST["loginPassword"];

    // Validate form data (you can add more validation as needed)
    if (empty($email) || empty($password)) {
        // If any field is empty, redirect back to the login page with an error message
        header("Location: login.php?error=emptyfields");
        exit();
    } else {
        // Add your database connection code here (assuming you're using MySQLi)

        // For demonstration purposes, let's assume we're connecting to a MySQL database
        $servername = "localhost";
        $username = "root";
        $dbpassword = "";
        $dbname = "teashop";

        // Create connection
        $conn = new mysqli($servername, $username, $dbpassword, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement to retrieve user data from the database
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the user exists in the database
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Verify the password
            if (password_verify($password, $row['password'])) {
                // Password is correct, set session variables
                $_SESSION['user_id'] = $row['user_id'];
                $_SESSION['email'] = $row['email'];
                // Redirect to the dashboard or any other desired page
                header("Location: index.php");
                exit();
            } else {
                // If password is incorrect, redirect back to the login page with an error message
                header("Location: login.php?error=invalidpassword");
                exit();
            }
        } else {
            // If user does not exist, redirect back to the login page with an error message
            header("Location: login.php?error=usernotfound");
            exit();
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
} else {
    // If the form was not submitted, redirect back to the login page
    header("Location: login.php");
    exit();
}
?>
