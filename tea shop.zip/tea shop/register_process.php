<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $fullName = $_POST["registerName"];
    $email = $_POST["registerEmail"];
    $password = $_POST["registerPassword"];

    // Validate form data (you can add more validation as needed)
    if (empty($fullName) || empty($email) || empty($password)) {
        // If any field is empty, redirect back to the registration page with an error message
        header("Location: register.php?error=emptyfields");
        exit();
    } else {
        // Add your database connection code here (assuming you're using MySQLi)

        // For demonstration purposes, let's assume we're connecting to a MySQL database
        $servername = "localhost";
        $username = "root";
        $dbpassword = "";
        $dbname = "teashop";

        // Create connection
        $conn = new mysqli($servername, $username, $dbpassword, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Hash the password before storing it in the database (for security)
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL statement to insert data into the database
        $sql = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        // Check if the SQL statement was prepared successfully
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        // Bind parameters to the prepared statement
        $stmt->bind_param("sss", $fullName, $email, $hashedPassword);

        // Execute the prepared statement
        if ($stmt->execute()) {
            // Registration successful, redirect to a success page
            header("Location: registration_success.php");
            exit();
        } else {
            // If execution failed, redirect back to the registration page with an error message
            header("Location: register.php?error=sqlerror");
            exit();
        }

        // Close statement and connection
        $stmt->close();
        $conn->close();
    }
} else {
    // If the form was not submitted, redirect back to the registration page
    header("Location: register.php");
    exit();
}
?>
