<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Success - Tea Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <h1>Tea Shop</h1>
            <!-- Navigation Menu -->
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="teas.php">Tea Types</a></li>
                    <li><a href="offers.php">Special Offers</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="logout.php">Logout</a></li>

                </ul>
            </nav>
        </div>
    </header>

    <!-- Registration Success Message -->
    <section class="registration-success">
        <div class="container">
            <h2>Registration Successful</h2>
            <p>Thank you for registering with Tea Shop. You can now login to your account.</p>
            <a href="login.php" class="btn btn-primary">Login</a>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2024 Tea Shop. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
