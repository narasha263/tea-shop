<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Tea Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Custom styling for the sidebar */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #333;
            padding-top: 20px;
            border-right: 1px solid #dee2e6;
            color: while;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            padding-left: 20px;
            color: while;
        }

        .sidebar a {
            padding: 10px 20px;
            text-decoration: none;
            font-size: 18px;
            color: #fff;
            display: block;
            transition: background-color 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #e9ecef;
        }

        /* Main content styling */
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }

        /* Header styling */
        header {
            background-color: #343a40;
            color: #fff;
            padding: 20px;
            margin-bottom: 20px;
        }

        header h1 {
            margin: 0;
        }

        /* Footer styling */
        footer {
            background-color: #343a40;
            color: #fff;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <a href="manage_teas.php">Manage Teas</a>
        <a href="add_tea.php">Add Tea</a>
        <a href="logout.php">Logout</a>
    </div>
    <style>
        /* Add your CSS styles here */
        .tea-container {
            display: flex;
            flex-wrap: wrap;
            background-color: #333;
            margin-left: 300px;
        }
        .tea-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin: 10px;
            width: 200px;
        }
        .tea-item img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Our Teas</h1>
    <div class="tea-container">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "teashop";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check if the connection is successful
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve tea details from the database
        $sql = "SELECT * FROM teas";
        $result = $conn->query($sql);

        // Check if the query was successful
        if ($result) {
            // Check if there are any results
            if ($result->num_rows > 0) {
                // Loop through each row of data
                while($row = $result->fetch_assoc()) {
                    echo '<div class="tea-item">';
                    echo '<img src="images/' . $row['image'] . '" alt="' . $row['name'] . '">';
                    echo '<h2>' . $row['name'] . '</h2>';
                    echo '<p>KES' . $row['price'] . '</p>';
                    echo '<p>Quantity: ' . $row['quantity'] . ' ' . $row['unit'] . '</p>';
                    // Add edit and delete buttons for admin
                    echo '<form action="edit_tea.php" method="post">';
                    echo '<input type="hidden" name="tea_id" value="' . $row['id'] . '">';
                    echo '<button type="submit">Edit</button>';
                    echo '</form>';
                    echo '<form action="delete_tea.php" method="post">';
                    echo '<input type="hidden" name="tea_id" value="' . $row['id'] . '">';
                    echo '<button type="submit">Delete</button>';
                    echo '</form>';
                    echo '</div>';
                }
            } else {
                echo "No teas found.";
            }
        } else {
            echo "Error: " . $conn->error;
        }

        // Close the database connection
        $conn->close();
        ?>
    </div><br>
    <?php include "footer.php" ?>  
</body>
</html>
