<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Tea</title>
    <style>
        /* Add your CSS styles here */
        /* You can style the form fields and buttons here */
    </style>
</head>
<body>
    <h1>Edit Tea</h1>
    
    <?php
    // Check if the tea_id is provided via POST
    if (isset($_POST['tea_id'])) {
        $tea_id = $_POST['tea_id'];

        // Include your database connection file
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "teashop";

        $conn = new mysqli($servername, $username, $password, $dbname);

         // Check if the connection is successful
         if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // Retrieve tea details from the database based on the tea_id
        $sql = "SELECT * FROM teas WHERE id = $tea_id";
        $result = $conn->query($sql);

        // Check if there is a result
        if ($result->num_rows > 0) {
            // Fetch the tea details
            $row = $result->fetch_assoc();
    ?>
    
    <!-- Display the form pre-filled with the current tea details -->
    <form action="update_tea.php" method="post">
        <input type="hidden" name="tea_id" value="<?php echo $row['id']; ?>">
        <label for="name">Tea Name:</label><br>
        <input type="text" id="image" name="image" value="<?php echo $row['image']; ?>"><br>
        <label for="image">Image:</label><br>
        <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>"><br>
        <label for="price">Price:</label><br>
        <input type="text" id="price" name="price" value="<?php echo $row['price']; ?>"><br>
        <label for="quantity">Quantity:</label><br>
        <input type="text" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>"><br>
        <label for="unit">Unit:</label><br>
        <input type="text" id="unit" name="unit" value="<?php echo $row['unit']; ?>"><br><br>
        <button type="submit">Update Tea</button>
    </form>
    
    <?php
        } else {
            echo "Tea not found.";
        }

        // Close the database connection
        $conn->close();
    } else {
        echo "Invalid request.";
    }
    ?>

    <?php include "footer.php"; ?>
</body>
</html>
