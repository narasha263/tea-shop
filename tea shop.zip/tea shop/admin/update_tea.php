<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Tea</title>
    <style>
        /* Add your CSS styles here */
        /* You can style the form fields and buttons here */
    </style>
</head>
<body>
    <h1>Update Tea</h1>
    
    <?php
    // Check if the form is submitted with tea_id and other fields
    if (isset($_POST['tea_id']) && isset($_POST['name']) && isset($_POST['image']) && isset($_POST['price']) && isset($_POST['quantity']) && isset($_POST['unit'])) {
        // Extract data from the POST request
        $tea_id = $_POST['tea_id'];
        $name = $_POST['name'];
        $image = $_POST['image'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        $unit = $_POST['unit'];
// Include your database connection file
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teashop";

$conn = new mysqli($servername, $username, $password, $dbname);

 // Check if the connection is successful
 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

        // Prepare and execute the update query
        $sql = "UPDATE teas SET name='$name', image='$image', price='$price', quantity='$quantity', unit='$unit' WHERE id='$tea_id'";
        if ($conn->query($sql) === TRUE) {
            echo "Tea updated successfully.";
            // Redirect back to the manage teas page
            header("Location: manage_teas.php");
            exit();
        } else {
            echo "Error updating tea: " . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        echo "Invalid request.";
    }
    ?>

    <?php include "footer.php"; ?>
</body>
</html>
