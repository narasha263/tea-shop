<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Tea</title>
    <style>
        /* Add your CSS styles here */
        /* You can style the form fields and buttons here */
    </style>
</head>
<body>
    <h1>Add Tea</h1>
    
    <!-- Add Tea Form -->
    <form action="add_tea_handler.php" method="post">
        <label for="name">Tea Name:</label><br>
        <input type="text" id="name" name="name" required><br>
        <label for="image">Image:</label><br>
        <input type="text" id="image" name="image" required><br>
        <label for="price">Price:</label><br>
        <input type="number" id="price" name="price" required><br>
        <label for="quantity">Quantity:</label><br>
        <input type="number" id="quantity" name="quantity" required><br>
        <label for="unit">Unit:</label><br>
        <input type="text" id="unit" name="unit" required><br><br>
        <button type="submit">Add Tea</button>
    </form>

    <?php include "footer.php"; ?>
</body>
</html>
