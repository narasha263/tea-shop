<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Tea Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Add your custom styling here */
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <header>
            <div class="container">
                <h1>Edit User</h1>
            </div>
        </header>

        <!-- Main Content -->
        <section class="admin-content">
            <div class="container">
                <!-- Add user edit form here -->
                <?php
                // Include your database connection file
                include_once 'db_connection.php';

                // Check if user_id is provided via GET
                if(isset($_GET['user_id'])) {
                    $user_id = $_GET['user_id'];

                    // Retrieve user data based on user_id
                    $sql = "SELECT * FROM users WHERE user_id = $user_id";
                    $result = $conn->query($sql);

                    // Check if user exists
                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                ?>
                <!-- Display user edit form pre-filled with user data -->
                <form action="update_user.php" method="post">
                    <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                    <label for="full_name">Full Name:</label><br>
                    <input type="text" id="full_name" name="full_name" value="<?php echo $row['full_name']; ?>"><br>
                    <label for="email">Email:</label><br>
                    <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>"><br>
                    <label for="password">Password:</label><br>
                    <input type="password" id="password" name="password" value="<?php echo $row['password']; ?>"><br><br>
                    <button type="submit" class="btn btn-primary">Update User</button>
                </form>
                <?php
                    } else {
                        echo "User not found.";
                    }
                } else {
                    echo "Invalid request.";
                }
                ?>
            </div>
        </section>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
