<?php include "header.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Tea</title>
    <style>
        /* Add your CSS styles here */
        /* You can style the confirmation message and buttons here */
    </style>
</head>
<body>
    <h1>Delete Tea</h1>
    
    <?php
    // Check if the tea_id is provided via POST
    if (isset($_POST['tea_id'])) {
        $tea_id = $_POST['tea_id'];

        // Include your database connection file
        include_once 'db_connection.php';

        // Prepare and execute the delete query
        $sql = "DELETE FROM teas WHERE id = '$tea_id'";
        if ($conn->query($sql) === TRUE) {
            echo "Tea deleted successfully.";
        } else {
            echo "Error deleting tea: " . $conn->error;
        }

        // Close the database connection
        $conn->close();
    } else {
        echo "Invalid request.";
    }
    ?>

    <?php include "footer.php"; ?>
</body>
</html>
