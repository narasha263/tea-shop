<?php
include_once 'db_connection.php'; // Include your database connection file

// Retrieve form data
$name = $_POST['name'];
$image = $_POST['image'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];
$unit = $_POST['unit'];

// Prepare and execute the insert query
$sql = "INSERT INTO teas (name, image, price, quantity, unit) VALUES ('$name', '$image', $price, $quantity, '$unit')";
if ($conn->query($sql) === TRUE) {
    echo "Tea added successfully.";
} else {
    echo "Error adding tea: " . $conn->error;
}

// Close the database connection
$conn->close();
?>
