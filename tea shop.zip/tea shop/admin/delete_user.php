<?php
// Include your database connection file
include_once 'db_connection.php';

// Check if user_id is provided via GET
if(isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Delete user from the database based on user_id
    $sql = "DELETE FROM users WHERE user_id = $user_id";

    if ($conn->query($sql) === TRUE) {
        echo "User deleted successfully";
    } else {
        echo "Error deleting user: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

// Redirect back to manage_users.php
header("Location: users.php");
exit();
?>
