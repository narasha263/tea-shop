<?php
// Include your database connection file
include_once 'db_connection.php';

// Check if form is submitted and user_id is provided
if(isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Update user data in the database
    $sql = "UPDATE users SET full_name='$full_name', email='$email', password='$password' WHERE user_id=$user_id";

    if ($conn->query($sql) === TRUE) {
        echo "User updated successfully";
    } else {
        echo "Error updating user: " . $conn->error;
    }
} else {
    echo "Invalid request.";
}

// Redirect back to manage_users.php
header("Location: users.php");
exit();
?>
