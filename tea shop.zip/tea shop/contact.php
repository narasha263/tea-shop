<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Tea Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Header -->
    <header>
        <div class="container">
            <h1>Tea Shop</h1>
            <!-- Navigation Menu -->
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="teas.php">Tea Types</a></li>
                    <li><a href="offers.php">Special Offers</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="logout.php">Logout</a></li>

                </ul>
            </nav>
        </div>
    </header>

    <!-- Banner/Slider Section -->
    <section class="banner">
        <div class="container">
            <h2>Contact Us</h2>
            <p>Got questions or feedback? Reach out to us using the form below.</p>
        </div>
    </section>

    <!-- Contact Form Section -->
    <section class="contact-form">
        <div class="container">
            <h2>Send Us a Message</h2>
            <form action="contact_process.php" method="post">
                <div class="mb-3">
                    <label for="name" class="form-label">Your Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Your Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="message" class="form-label">Your Message</label>
                    <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
    </section>
    <section class="contact">
            <h2>Get in Touch</h2>
            <p>For any inquiries or assistance, please feel free to contact us:</p>
            <ul>
                <li>Email: rebeccaahmed04.56@gmail.com</li>
                <li>Phone: +254 102561020</li>
                <li>Address: Rainbow Resort, Ruiru, Kenya</li>
            </ul>
        </section>
    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2024 Tea Shop. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html>
