<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Tea Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <!-- Header -->
    <header>
        <div class="container">
            <h1>Tea Shop</h1>
            <!-- Navigation Menu -->
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="teas.php">Tea Types</a></li>
                    <li><a href="offers.php">Special Offers</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="logout.php">Logout</a></li>

                </ul>
            </nav>
        </div>
    </header>

    <!-- Banner/Slider Section -->
    <section class="banner">
        <div class="container">
            <h2>About Us</h2>
            <p>Learn more about our Tea Shop and our commitment to providing the finest teas to our customers.</p>
        </div>
    </section>

    <!-- About Us Section -->
    <section class="about-us">
        <div class="container">
            <h2>Our Story</h2>
            <p>Welcome to Tea Shop, your one-stop destination for premium teas sourced from around the world. Our journey began with a passion for high-quality, flavorful teas and a desire to share that passion with others.</p>
            <p>At Tea Shop, we believe in offering a diverse selection of teas to suit every palate. From classic green teas to exotic herbal blends, each of our teas is carefully selected and sourced to ensure the highest standards of quality and taste.</p>
            <p>Our team is dedicated to providing exceptional customer service and sharing our knowledge and expertise about teas. Whether you're a tea enthusiast or new to the world of tea, we're here to help you discover new flavors and experiences.</p>
            <p>Thank you for choosing Tea Shop. We look forward to serving you and sharing the joy of tea!</p>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2024 Tea Shop. All rights reserved.</p>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html>
