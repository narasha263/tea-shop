<?php include "header.php" ?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Special Offers</title>
    <style>
        /* Add your CSS styles here */
        .tea-container {
            display: flex;
            flex-wrap: wrap;
            background-color: #333;
        }
        .tea-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin: 10px;
            width: 200px;
        }
        .tea-item img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Special Offers</h1>
    <div class="tea-container">
        <?php
        // Sample array of special offers
        $special_offers = [
            [
                'name' => 'Special Offer Tea<h5>Black Tea</h5>',
                'image' => 'black tea.jpg',
                'price' => 300, // Special price
                'quantity' => 0.5,
                'unit' => 'kg'
            ],
            [
                'name' => 'Special Offer Tea <h5>Safari Tea</h5>',
                'image' => 'safari tea.jpg',
                'price' => 450, // Special price
                'quantity' => 0.5,
                'unit' => 'kg'
            ],
            [
                'name' => 'Special Offer Tea <h5>Hibiscus Tea</h5>',
                'image' => 'hibiscus tea.jpg',
                'price' => 2000, // Special price
                'quantity' => 0.5,
                'unit' => 'kg'
            ],
            [
                'name' => 'Special Offer Tea <h5>Herbal Tea</h5>',
                'image' => 'herbal tea.jpg',
                'price' => 450, // Special price
                'quantity' => 0.5,
                'unit' => 'kg'
            ],
            [
                'name' => 'Special Offer Tea <h5>Kericho Gold Tea</h5>',
                'image' => 'kericho gold tea.jpg',
                'price' => 850, // Special price
                'quantity' => 0.5,
                'unit' => 'kg'
            ],
            [
                'name' => 'Special Offer Tea <h5>Greean Tea</h5>',
                'image' => 'green tea.jpg',
                'price' => 300, // Special price
                'quantity' => 0.5,
                'unit' => 'kg'
            ],
            // Add more special offers as needed
        ];

        // Loop through special offers array and display each special offer
        foreach ($special_offers as $tea) {
            echo '<div class="tea-item">';
            echo '<img src="special offer/' . $tea['image'] . '" alt="' . $tea['name'] . '">';
            echo '<h2>' . $tea['name'] . '</h2>';
            echo '<p>Special Price: KES' . $tea['price'] . '</p>';
            echo '<p>Quantity: ' . $tea['quantity'] . ' ' . $tea['unit'] . '</p>';
            echo '<form action="order.php" method="post">';
            echo '<input type="hidden" name="tea_name" value="' . $tea['name'] . '">';
            echo '<input type="hidden" name="price" value="' . $tea['price'] . '">';
            echo '<button type="submit">Order Now</button>';
            echo '</form>';
            echo '</div>';
        }
        ?>
    </div>
    <h1>Other Teas</h1>
    <div class="tea-container">
        <?php
        // Sample array of teas excluding special offers
        $teas = [
            [
                'name' => 'Fahari ya Kenya Tea',
                'image' => 'fahari ya kenya.jpg',
                'price' => 600,
                'quantity' => 0.25,
                'unit' => 'kg'
            ],
            [
                'name' => 'White Tea',
                'image' => 'white tea.jpg',
                'price' => 600,
                'quantity' => 0.25,
                'unit' => 'kg'
            ],
            [
                'name' => 'Ketepa Tea',
                'image' => 'ketepa tea.jpg',
                'price' => 500,
                'quantity' => 0.25,
                'unit' => 'kg'
            ],
            // Add more teas here
        ];

        // Loop through teas array and display each tea
        foreach ($teas as $tea) {
            echo '<div class="tea-item">';
            echo '<img src="images/' . $tea['image'] . '" alt="' . $tea['name'] . '">';
            echo '<h2>' . $tea['name'] . '</h2>';
            echo '<p>KES' . $tea['price'] . '</p>';
            echo '<p>Quantity: ' . $tea['quantity'] . ' ' . $tea['unit'] . '</p>';
            echo '<form action="order.php" method="post">';
            echo '<input type="hidden" name="tea_name" value="' . $tea['name'] . '">';
            echo '<input type="hidden" name="price" value="' . $tea['price'] . '">';
            echo '<button type="submit">Order Now</button>';
            echo '</form>';
            echo '</div>';
        }
        ?>
    </div><br>
    <?php include "footer.php" ?>  
</body>
</html>
