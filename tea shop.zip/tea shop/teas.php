<?php include "header.php" ?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teas</title>
    <style>
        /* Add your CSS styles here */
        .tea-container {
            display: flex;
            flex-wrap: wrap;
            background-color: #333;
        }
        .tea-item {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin: 10px;
            width: 200px;
        }
        .tea-item img {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>Our Teas</h1>
    <div class="tea-container">
        <?php
        // Include your database connection file
        include_once 'db_connection.php';

        // Retrieve tea details from the database
        $sql = "SELECT * FROM teas";
        $result = $conn->query($sql);

        // Check if there are any results
        if ($result->num_rows > 0) {
            // Loop through each row of data
            while($row = $result->fetch_assoc()) {
                echo '<div class="tea-item">';
                echo '<img src="images/' . $row['image'] . '" alt="' . $row['name'] . '">';
                echo '<h2>' . $row['name'] . '</h2>';
                echo '<p>KES' . $row['price'] . '</p>';
                echo '<p>Quantity: ' . $row['quantity'] . ' ' . $row['unit'] . '</p>';
                echo '<form action="order.php" method="post">';
                echo '<input type="hidden" name="tea_name" value="' . $row['name'] . '">';
                echo '<input type="hidden" name="price" value="' . $row['price'] . '">';
                echo '<button type="submit">Order Now</button>';
                echo '</form>';
                echo '</div>';
            }
        } else {
            echo "No teas found.";
        }
        ?>
    </div><br>
    <?php include "footer.php" ?>  
</body>
</html>
