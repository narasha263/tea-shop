<?php include "header.php"; ?><br>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        /* Add your CSS styles here */
        .container {
            max-width: 800px;
            margin: auto;
            text-align: center;
            padding: 20px;
        }
        .confirmation-message {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .payment-form {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Order Confirmation</h1>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $tea_name = $_POST['tea_name'];
            $price = $_POST['price'];
            echo '<p class="confirmation-message">Thank you for your order!</p>';
            echo '<p>You have ordered: ' . $tea_name . '</p>';
            echo '<p>Price: KES ' . $price . '</p>';
        } else {
            echo '<p class="confirmation-message">Invalid request!</p>';
        }
        ?>
       <form class="payment-form" action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="business" value="narasha263@gmail.com">
    <input type="hidden" name="item_name" value="<?php echo htmlspecialchars($tea_name); ?>">
    <input type="hidden" name="amount" value="<?php echo htmlspecialchars($price); ?>">
    <input type="hidden" name="currency_code" value="USD">
    <input type="hidden" name="button_subtype" value="services">
    <input type="hidden" name="no_note" value="0">
    <input type="hidden" name="tax_rate" value="0.000">
    <input type="hidden" name="shipping" value="0.00">
    <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynowCC_LG.gif:NonHostedGuest">
    <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
    <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

    </div>
</body>
</html>

<?php include "footer.php"; ?>
